
package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import com.example.psiqu.databinding.ActivityHome2Binding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*
import kotlin.math.log

class Home : AppCompatActivity() {
    private lateinit var home : ActivityHome2Binding
    val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home = ActivityHome2Binding.inflate(layoutInflater)

        val email = intent.getStringExtra("email")

        //variaveis doutor
        val esteid = intent.getStringExtra("Iddoutor")
        val estenome = intent.getStringExtra("NomeDoutor")

        //val juncao = estenome+esteid

        setContentView(home.root)
        val paciente = db.collection("Pacientes").whereEqualTo("Email", email)
        val doutor = db.collection("Doutores").whereEqualTo("Email", email)
        //val colecaoconversadoutor = db.collection("Conversas").document(juncao)


        doutor.get().addOnSuccessListener { documentor ->
            for (docs in documentor){
                Log.d(ContentValues.TAG, "Bungas: ${docs.data}")
                val dias = "${docs.get("Dias")}"

                //"${docs["Teste.0"]}"
                //val map = mapOf()

                Log.d(ContentValues.TAG, "Bungas:" + dias)

                if (docs.exists()) {
                    home.conversas.setOnClickListener{
                        val intent = Intent(this, BuscaUserConversaDoutor::class.java)
                        intent.putExtra("id", esteid)
                        intent.putExtra("nome", estenome)

                        startActivity(intent)
                    }
                    home.BuscarDoutor.setOnClickListener{
                        val intent = Intent(this, BuscaPaciente::class.java)
                        intent.putExtra("email",email )
                        intent.putExtra("id", esteid)
                        intent.putExtra("nome", estenome)
                        startActivity(intent)
                    }
                    home.Verperfil.setOnClickListener{
                        val intent = Intent(this, Meuperfil_psi::class.java)
                        intent.putExtra("email",email )
                        intent.putExtra("id", esteid)
                        intent.putExtra("nome", estenome)
                        intent.putExtra("localidade", "${docs.get("Localidade")}")
                        intent.putExtra("formação", "${docs.get("Formação")}")
                        intent.putExtra("dias", dias)
                        intent.putExtra("crm", "${docs.get("CRM")}")

                        startActivity(intent)
                    }
                    home.Agenda.setOnClickListener{
                        val paginacalendar = Intent(this, ChecarConsultas::class.java)
                        paginacalendar.putExtra("iddoutor", "${docs.get("Meu iD")}")
                        startActivity(paginacalendar)
                    }
                    home.home.setOnClickListener{
                        val estaintent = Intent(this, PostagensGerais::class.java)
                        estaintent.putExtra("id", "${docs.get("Meu iD")}")
                        startActivity(estaintent)
                    }
                }

            }
        }




        paciente.get().addOnSuccessListener { estedocs ->
            for (estedoc in estedocs){
                if(estedoc.exists()){
                    home.conversas.setOnClickListener {
                        val intent = Intent(this, BuscaUser::class.java)
                        intent.putExtra("email",email )
                        startActivity(intent)
                    }

                    home.BuscarDoutor.setOnClickListener{
                        val intent = Intent(this, BuscaDoutor::class.java)
                        intent.putExtra("email",email )
                        startActivity(intent)
                    }

                    home.Verperfil.setOnClickListener{
                        val intent = Intent(this, Meuperfil_paciente::class.java)
                        intent.putExtra("email",email )
                        intent.putExtra("id", "${estedoc.get("Meu iD")}")
                        intent.putExtra("nome", "${estedoc.get("Nome")}")
                        intent.putExtra("problema", "${estedoc.get("Problema")}")
                        intent.putExtra("Local", "${estedoc.get("Local")}")
                        startActivity(intent)
                    }
                    home.Agenda.setOnClickListener{
                        val paginacalendar = Intent(this, ChecarConsultas::class.java)
                        paginacalendar.putExtra("idpaciente", "${estedoc.get("Meu iD")}")
                        startActivity(paginacalendar)
                    }
                    home.home.setOnClickListener{
                        val estaintent = Intent(this, PostagensGerais::class.java)
                        startActivity(estaintent)
                    }
                }
            }
        }







        home.Logout.setOnClickListener{
            startActivity(Intent(this,MainActivity::class.java))
        }

        if(intent.getStringExtra("NomeDoutor").isNullOrBlank()){
            home.btperfil.setText(intent.getStringExtra("nomepaciente"))
        }
        else{
            home.btperfil.setText(intent.getStringExtra("NomeDoutor"))
        }

    }


}

