package com.example.psiqu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AreadeTestes : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_areade_testes)
    }
}