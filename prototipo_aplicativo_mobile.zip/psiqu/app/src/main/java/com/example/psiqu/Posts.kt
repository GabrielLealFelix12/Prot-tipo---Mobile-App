package com.example.psiqu.models

import com.google.firebase.database.PropertyName
import com.google.firebase.firestore.auth.User


data class Posts (
        //var description: String = "",
        @get:PropertyName("estecampo") @set:PropertyName("estecampo")var estecampo: String = "",
        @get:PropertyName("creation_time_ms") @set:PropertyName("creation_time_ms") var creationTimeMs: Number = 0,
        //var user: User? = null
)
