package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.ContentView
import com.example.psiqu.databinding.ActivityPerfilPsicologBinding
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import com.squareup.picasso.Picasso

class Meuperfil_psi : AppCompatActivity() {
    //private lateinit var perfil_dr: ActivityPerfilPsicologBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //perfil_dr= ActivityPerfilPsicologBinding.inflate(layoutInflater)
        val minhastorage = Firebase.storage
        var storageref = minhastorage.reference




        val iddoutor = intent.getStringExtra("id")
        val nomedoutor = intent.getStringExtra("nome")
        val emaildoutor = intent.getStringExtra("email").toString()
        val localizacao = intent.getStringExtra("localidade")
        val formacao = intent.getStringExtra("formação")
        val dias = intent.getStringExtra("dias")
        val crm = intent.getStringExtra("crm")

        val perfildoutor = getLayoutInflater().inflate(R.layout.activity_meuperfil_psi, null)
        val meunome = perfildoutor.findViewById<TextView>(R.id.Nome_doutor)
        val meuemail = perfildoutor.findViewById<TextView>(R.id.EmailDoutor)
        val meuuniversidade = perfildoutor.findViewById<TextView>(R.id.UniversidadeDoutor).text
        val localatendimento = perfildoutor.findViewById<TextView>(R.id.LocalAtendimento).text
        val perfilfoto = perfildoutor.findViewById<ImageView>(R.id.Img_doutor)
        val meusdias = perfildoutor.findViewById<TextView>(R.id.DiasAtendimento)

        val universidade = perfildoutor.findViewById<TextView>(R.id.UniversidadeDoutor)
        val local = perfildoutor.findViewById<TextView>(R.id.LocalAtendimento)

        val editperfil = perfildoutor.findViewById<ImageView>(R.id.EditPerfil)
        val minhahome = perfildoutor.findViewById<ImageView>(R.id.minhahome)

        editperfil.setOnClickListener{
            val intent = Intent(this, EditPerfilPsicog::class.java)
            intent.putExtra("nome", nomedoutor)
            intent.putExtra("email", emaildoutor)
            intent.putExtra("Formação", meuuniversidade )
            intent.putExtra("LocalAtendimento", localatendimento)
            intent.putExtra("id", iddoutor)
            intent.putExtra("crm", crm)
            startActivity(intent)
        }

        minhahome.setOnClickListener{
            finish()
        }
        meunome.setText(nomedoutor)
        meuemail.setText(emaildoutor)
        universidade.setText(formacao)
        local.setText(localizacao)
        meusdias.setText(dias)

        storageref.child(iddoutor+"/"+"imageperfil.jpg").downloadUrl.addOnSuccessListener { result ->
            Log.d(ContentValues.TAG, result.toString())
            Picasso.get().load(result).into(perfilfoto)
        }

        setContentView(perfildoutor)


    }
}