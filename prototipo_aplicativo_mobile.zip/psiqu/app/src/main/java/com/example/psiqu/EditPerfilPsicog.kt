package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
//import android.provider.MediaStore
import android.util.Log
//import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.psiqu.databinding.ActivityPerfilupdatePsiBinding
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
//import com.squareup.picasso.Picasso
import java.io.ByteArrayOutputStream
//import java.io.File
import java.io.InputStream


class EditPerfilPsicog : AppCompatActivity() {
    private lateinit var editperfil : ActivityPerfilupdatePsiBinding
    lateinit var  inputstreamfodas: InputStream
    var dias = listOf<String>().toMutableList()

    var resultLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { result : Uri->
        inputstreamfodas = contentResolver.openInputStream(result)!!
        //essaimage.putStream(inputstreamfodas)
        val bitmap = BitmapFactory.decodeStream(inputstreamfodas)
        inputstreamfodas.close()
        editperfil.Fotoperfil.setImageBitmap(bitmap)

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val meunome =  intent.getStringExtra("nome").toString()
        val meuemail = intent.getStringExtra("email")
        val id = intent.getStringExtra("id")
        val meuuniversidade = intent.getStringExtra("Formação")
        val localatendimento = intent.getStringExtra("LocalAtendimento")
        val crm = intent.getStringExtra("crm")


        editperfil = ActivityPerfilupdatePsiBinding.inflate(layoutInflater)

        editperfil.NomeDoutor.setText(meunome)
        editperfil.editemail.setText(meuemail)
        editperfil.UniDoutor.setText(meuuniversidade)
        editperfil.localDeAtendimento.setText(localatendimento)
        editperfil.CRM.setText(crm)

        editperfil.sab.setOnCheckedChangeListener{ buttonview, ischecked ->
            if(ischecked){
                dias.add(editperfil.sab.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }else{
                dias.remove(editperfil.sab.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }
        }
        editperfil.dom.setOnCheckedChangeListener{ buttonview, ischecked ->
            if(ischecked){
                dias.add(editperfil.dom.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }else{
                dias.remove(editperfil.dom.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }
        }

        editperfil.seg.setOnCheckedChangeListener{ buttonview, ischecked ->
            if(ischecked){
                dias.add(editperfil.seg.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }else{
                dias.remove(editperfil.seg.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }
        }

        editperfil.ter.setOnCheckedChangeListener{ buttonview, ischecked ->
            if(ischecked){
                dias.add(editperfil.ter.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }else{
                dias.remove(editperfil.ter.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }
        }

        editperfil.qua.setOnCheckedChangeListener{ buttonview, ischecked ->
            if(ischecked){
                dias.add(editperfil.qua.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }else{
                dias.remove(editperfil.qua.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }
        }
        editperfil.qui.setOnCheckedChangeListener{ buttonview, ischecked ->
            if(ischecked){
                dias.add(editperfil.qui.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }else{
                dias.remove(editperfil.qui.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }
        }

        editperfil.sex.setOnCheckedChangeListener{ buttonview, ischecked ->
            if(ischecked){
                dias.add(editperfil.sex.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }else{
                dias.remove(editperfil.sex.text.toString())
                Log.d(ContentValues.TAG, "bungas" + dias)
            }
        }


        setContentView(editperfil.root)
        editperfil.EscolherImagemPerfil.setOnClickListener{
            resultLauncher.launch("image/*")
        }

        editperfil.CONFIRMAR.setOnClickListener{
            val db = Firebase.firestore
            val nome = editperfil.NomeDoutor.text.toString()
            val email =  editperfil.editemail.text.toString()
            val facul = editperfil.UniDoutor.text.toString()
            val localatendimento = editperfil.localDeAtendimento.text.toString()
            val mycrm = editperfil.CRM.text.toString()

            val user = hashMapOf(
                "Email" to email,
                "Nome" to nome,
                "Doutor" to true,
                "Formação" to facul,
                "Localidade" to localatendimento,
                "Dias" to dias,
                "CRM" to mycrm
            )

            db.collection("Doutores")
                .whereEqualTo("Meu iD", id)
                .get()
                .addOnSuccessListener { documento ->
                    for (docs in documento){
                    Log.d(ContentValues.TAG, "Doutor encontrado: ${docs.id}")
                    db.collection("Doutores")
                        .document("${docs.id}")
                        .set(user, SetOptions.merge())
                        Toast.makeText(this,"Dados Atualizados com sucesso", Toast.LENGTH_SHORT).show()
                    }
                }

            var storage = Firebase.storage

            var storageRef = storage.reference
            var imagesRef: StorageReference? = storageRef.child(id+"/"+"imageperfil.jpg")
            editperfil.Fotoperfil.isDrawingCacheEnabled = true
            editperfil.Fotoperfil.buildDrawingCache()
            val bitmap = ( editperfil.Fotoperfil.drawable as BitmapDrawable).bitmap
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val data = baos.toByteArray()

            var uploadTask = imagesRef!!.putBytes(data)




            uploadTask.addOnFailureListener {
            Log.e(ContentValues.TAG,"Error")
            }
                .addOnSuccessListener { taskSnapshot ->
            Log.d(ContentValues.TAG, "done: " + taskSnapshot.metadata)
                }


            var intent = Intent(this,Home::class.java)
            intent.putExtra("email", email)
            intent.putExtra("Iddoutor", id)
            intent.putExtra("nomepaciente", meunome)
            startActivity(intent)

}

        }

}


