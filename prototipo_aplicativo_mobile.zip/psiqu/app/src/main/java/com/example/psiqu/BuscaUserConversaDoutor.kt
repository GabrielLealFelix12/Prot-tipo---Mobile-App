package com.example.psiqu
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.psiqu.databinding.ActivityPerfisListaBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.example.psiqu.Paciente

class BuscaUserConversaDoutor : AppCompatActivity(){
    val db = Firebase.firestore
    private lateinit var listauser: ActivityPerfisListaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val userdoutor = intent.getStringExtra("id")
        val nomedoutor = intent.getStringExtra("nome")
        val essedoc = nomedoutor+userdoutor



            listauser = ActivityPerfisListaBinding.inflate(layoutInflater)
            setContentView(listauser.root)


        db.collection("Pacientes")
            .whereEqualTo(essedoc, true)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {

                    val userparalista = getLayoutInflater().inflate(R.layout.perfis_imagens, null);
                    val mudar = userparalista.findViewById<TextView>(R.id.name)
                    val nomedoutor = userparalista.findViewById<Button>(R.id.IdDoutor)
                    val espacolista = findViewById<LinearLayout>(R.id.container)

                    Log.d(ContentValues.TAG, "${document.get("Nome")}")


                    mudar.setText ("${document.get("Nome")}")
                    nomedoutor.setText("${document.get("Email")}")


                    espacolista.addView(userparalista)

                    userparalista.setOnClickListener{ atividade->
                        val nome_do_doutor = mudar.text;
                        val emailpaciente = nomedoutor.text
                        val busca = hashMapOf("Nome" to nome_do_doutor, "Meu id" to emailpaciente)

                        db.collection("Conversas")
                            .whereEqualTo("Doutor", busca)
                            .get()
                            .addOnSuccessListener { documento ->
                                Log.d(ContentValues.TAG, "${document.get("Doutor")}")
                                val intent = Intent(this, chatpsi::class.java)
                                intent.putExtra("essedoc", essedoc)
                                intent.putExtra("emailpaciente", emailpaciente)
                                startActivity(intent)
                            }
                    }


                }
            }
    }

}
        /*
        db.collection("Pacientes")
            .whereNotEqualTo("Email", null)
            .get()
            .addOnSuccessListener { documents ->
                for (docs in documents){
                    val emails =

                } */



