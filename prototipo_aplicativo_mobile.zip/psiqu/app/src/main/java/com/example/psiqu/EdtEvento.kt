package com.example.psiqu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class EdtEvento : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edt_evento)
    }
}