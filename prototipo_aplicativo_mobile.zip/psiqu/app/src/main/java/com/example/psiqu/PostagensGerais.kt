package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isInvisible
import com.example.psiqu.databinding.TelaPostagensBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import com.squareup.picasso.Picasso

class PostagensGerais : AppCompatActivity() {
    val db = Firebase.firestore
    private lateinit var telapostagens: com.example.psiqu.databinding.TelaPostagensBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")

        val minhastorage = Firebase.storage
        var storageref = minhastorage.reference

        telapostagens = TelaPostagensBinding.inflate(layoutInflater)

        db.collection("Posts").whereNotEqualTo("tempo", null).orderBy("tempo", com.google.firebase.firestore.Query.Direction.ASCENDING).get().addOnSuccessListener { docs ->
            for (doc in docs) {
                val pagepubli = getLayoutInflater().inflate(R.layout.posts_do_aplicativo, null);
                val nomedoutor = pagepubli.findViewById<TextView>(R.id.Nomedoutor)
                val textopubli = pagepubli.findViewById<TextView>(R.id.textopublicacao)
                val imgpubli = pagepubli.findViewById<ImageView>(R.id.publicacao)
                val imgperfil = pagepubli.findViewById<ImageView>(R.id.imagemdoutor)
                val publis = findViewById<LinearLayout>(R.id.mostrarpubli)
                db.collection("Doutores").document("${doc.get("doutor")}").get().addOnSuccessListener{ meudoc ->
                    nomedoutor.setText("${meudoc.get("Nome")}")

                    storageref.child("${meudoc.get("Meu iD")}"+'/'+"imageperfil.jpg").downloadUrl.addOnSuccessListener { result ->
                        Log.d(ContentValues.TAG, result.toString())
                        Picasso.get().load(result).into(imgperfil)
                    }
                }

                textopubli.setText("${doc.get("TextoPubli")}")

storageref.child("${doc.get("doutor")}"+'/'+"${doc.get("Meu iD")}").downloadUrl.addOnSuccessListener { result ->
    Log.d(ContentValues.TAG, result.toString())
    Picasso.get().load(result).into(imgpubli)
}
publis.addView(pagepubli)
            }
        }

if(id.isNullOrBlank()){
    telapostagens.Publicacoes.visibility = View.INVISIBLE
    }else{
    telapostagens.Publicacoes.setOnClickListener {
        val intent = Intent(this, MinhasPostagensPsicog::class.java)
        intent.putExtra("id", id)
        startActivity(intent)
    }
}
        setContentView(telapostagens.root)

    }
}