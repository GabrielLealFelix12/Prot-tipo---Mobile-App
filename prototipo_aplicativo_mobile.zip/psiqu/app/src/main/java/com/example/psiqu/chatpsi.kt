package com.example.psiqu

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import android.widget.TextView
import com.example.psiqu.databinding.ActivityChatBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class chatpsi : AppCompatActivity() {
    val db = Firebase.firestore
    private lateinit var telachat: ActivityChatBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        telachat = ActivityChatBinding.inflate(layoutInflater)
        setContentView(telachat.root)
        val send = telachat.MandarMensagem

        val essedoc = intent.getStringExtra("essedoc").toString()
        val emailpaciente = intent.getStringExtra("emailpaciente").toString()
        val conversacol = essedoc+emailpaciente

        val conversas = db.collection("Conversas").document(essedoc)
        conversas.get().addOnSuccessListener{ document ->
            if (document.exists()){
                Log.d(ContentValues.TAG, "Conversa encontrada: ${document.data}")
            }else{
                Log.d(ContentValues.TAG, "Nao ha conversas registradas!")
                Log.d(ContentValues.TAG, "Criando conversa...")
                conversas.set(essedoc)
            }
            db.collection("Conversas").
            document(essedoc).
            collection(conversacol)
                .orderBy("Tempo", com.google.firebase.firestore.Query.Direction.ASCENDING)
                .get()
                .addOnSuccessListener{ documento->
                    for(docs in documento){
                        val mensagemdb = getLayoutInflater().inflate(R.layout.mensagens_mostrar, null);
                        val mensagens = mensagemdb.findViewById<TextView>(R.id.estamensagem)
                        val mostrarmensagens = findViewById<LinearLayout>(R.id.mostrarestamensagem)

                        mensagens.setText ("${docs.get("Mensagem")}")
                        mostrarmensagens.addView(mensagemdb)


                    }

                }

        }.addOnFailureListener{ e ->
            Log.w(ContentValues.TAG, "Erro ao adicionar conversa", e)

        }
        send.setOnClickListener{
            val tempo = System.currentTimeMillis();
            val tempo_men = tempo.toString();
            val editmen = telachat.MensagemEdit.text.toString()
            val men = hashMapOf("Mensagem" to editmen, "Tempo" to tempo_men)

            //enough.set(myemail, SetOptions.merge())

            db.collection("Conversas").
            document(essedoc).
            collection(conversacol)
                .add(men)
                .addOnSuccessListener { documento ->
                    Log.d(ContentValues.TAG, "Mensagem  cadastrada...")

                }
            val mensagemdb = getLayoutInflater().inflate(R.layout.mensagens_mostrar, null);
            val mensagens = mensagemdb.findViewById<TextView>(R.id.estamensagem)
            val mostrarmensagens = findViewById<LinearLayout>(R.id.mostrarestamensagem)

            mensagens.setText(editmen)
            mostrarmensagens.addView(mensagemdb)

        }
    }
}


