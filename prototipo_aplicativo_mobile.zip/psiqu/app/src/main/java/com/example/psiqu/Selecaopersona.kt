package com.example.psiqu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.psiqu.databinding.ActivitySelecaopersonaBinding


class Selecaopersona : AppCompatActivity() {
    private lateinit var binding: ActivitySelecaopersonaBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelecaopersonaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.imageButton2.setOnClickListener{
            val intent = Intent(this, Paciente::class.java)
            startActivity(intent)
            //finish()
        }
        binding.imageButton3.setOnClickListener{
            val intent =  Intent(this, Psicologa::class.java)
            startActivity(intent)
            //finish()
        }

    }
}