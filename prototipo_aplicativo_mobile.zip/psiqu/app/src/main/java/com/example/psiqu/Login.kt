package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.psiqu.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class Login : AppCompatActivity() {
    private var auth = FirebaseAuth.getInstance()
    lateinit var binding: ActivityLoginBinding
    val db = Firebase.firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btlogar.setOnClickListener { view ->
            val email = binding.editEmail.text.toString()
            val senha = binding.editSenha.text.toString()

            if(email.isBlank() && senha.isBlank()){
                Toast.makeText(this,"Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }else{
                auth.signInWithEmailAndPassword(email,senha)
                    .addOnCompleteListener { autenticacao ->
                        val paciente = db.collection("Pacientes").whereEqualTo("Email",email)
                        val doutor = db.collection("Doutores").whereEqualTo("Email", email)

                        if (autenticacao.isSuccessful){
                            Toast.makeText(this,"Seja bem vindo", Toast.LENGTH_SHORT).show()

                            doutor
                                .get()
                                .addOnSuccessListener {documentor ->
                                    for (docs in documentor){
                                    if(docs.exists()){
                                        Log.d(ContentValues.TAG, "Este doutor: ${docs.data}")
                                        val doutorid = "${docs.get("Meu iD")}"
                                        val nomedoutor = "${docs.get("Nome")}"
                                        val email = "${docs.get("Email")}"
                                        var intent = Intent(this,Home::class.java)
                                        intent.putExtra("email", email)
                                        intent.putExtra("Iddoutor", doutorid)
                                        intent.putExtra("NomeDoutor", nomedoutor)
                                        startActivity(intent)
                                        finish()
                                    }
                                    }

                                }
                            paciente.get().addOnSuccessListener { estedocs ->
                                for (estedoc in estedocs){
                                    if(estedoc.exists()){
                                        Log.d(ContentValues.TAG, "Este paciente: ${estedoc.data}")
                                        val estepaciente = "${estedoc.get("Nome")}"
                                        val pacienteemail = "${estedoc.get("Email")}"
                                        var intent = Intent(this,Home::class.java)
                                        intent.putExtra("email", email)
                                        intent.putExtra("nomepaciente", estepaciente)
                                        startActivity(intent)
                                        finish()
                                    }
                                }
                            }
/*
                            var intent = Intent(this,Home::class.java)
                            intent.putExtra("email", email)
                            startActivity(intent)
                            finish()

 */
                        }else{
                            Toast.makeText(this,"Usuario não encontrado!", Toast.LENGTH_SHORT).show()
                        }

                    }
            }
        }
        binding.btesqueci.setOnClickListener {
            var intent = Intent(this, ForgotSenha::class.java)
            startActivity(intent)
            finish()
        }
        binding.btcads.setOnClickListener {
            startActivity(Intent(this,Selecaopersona::class.java))
            finish()
        }

    }
}
