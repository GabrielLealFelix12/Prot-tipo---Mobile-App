package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.psiqu.databinding.ActivityPacienteBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class Paciente : AppCompatActivity() {
    //private lateinit var auth: FirebaseAuth


    private lateinit var binding: ActivityPacienteBinding
    val ref = FirebaseAuth.getInstance();
    val db = Firebase.firestore





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActivityPacienteBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.cadPaciente.setOnClickListener { view ->
            val email = binding.EmailPaciente.text.toString()
            val senha = binding.PacienteSenha.text.toString()
            val nomepaciente = binding.NomePaciente.text.toString()
            val prob = binding.Problema.text.toString()
            val datadenascimento = binding.Datanascimento.text.toString()

            if (email.isBlank() || senha.isBlank() || nomepaciente.isBlank() || prob.isBlank() || datadenascimento.isBlank()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_LONG).show()

            } else {
                val user = hashMapOf(
                    "Email" to email,
                    "Nome" to nomepaciente,
                    "Problema" to prob,
                    "Data de Nascimento" to datadenascimento,
                    "Paciente" to true
                )
                ref.createUserWithEmailAndPassword(email, senha)
                .addOnCompleteListener { cadastro ->
                        if (cadastro.isSuccessful) {
                            Toast.makeText(this, "Cadastrado", Toast.LENGTH_LONG).show()

                            db.collection("Pacientes")
                                .add(user)
                                .addOnSuccessListener { documento ->
                                    Log.d(ContentValues.TAG, "Paciente cadastrado com ID: ${documento.id}")
                                    db.collection("Pacientes")
                                        .document("${documento.id}")
                                        .set(hashMapOf("Meu iD" to "${documento.id}"), SetOptions.merge())

                                    //public val itemList= arrayListOf("${documento.id}")
                                }
                                .addOnFailureListener { e ->
                                    Log.w(ContentValues.TAG, "Erro ao adicionar paciente", e)
                                }

                            var intent = Intent(this,Login::class.java)
                            startActivity(intent)
                            finish()
                        }
                    }.addOnFailureListener {


                    }
            }

        }
    }

}