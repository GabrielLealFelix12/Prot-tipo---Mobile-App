package com.example.psiqu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.psiqu.models.Posts
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.getField
import com.google.firebase.ktx.Firebase

private const val TAG = "PostsActivity"
class Post_Activity : AppCompatActivity() {
    private lateinit var firestoreDb: FirebaseFirestore
    private lateinit var posts: MutableList<Posts>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.item_post)

        posts = mutableListOf()

        firestoreDb = FirebaseFirestore.getInstance()
        val postReference = firestoreDb
            .collection("Posts")
            .limit(20)
            .orderBy("creation_time_ms", Query.Direction.DESCENDING)

        postReference.addSnapshotListener { snapshot, exception ->
            if(exception != null || snapshot == null){
                Log.e(TAG, "Exceção quando enfileira posts ", )
                return@addSnapshotListener
            }

            val postLlist = snapshot.toObjects( Posts::class.java )
            for (post in postLlist){
                Log.i(TAG, "Post: ${post} ")
            }

        }
    }
}