package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.psiqu.databinding.ActivityPsicologaBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


class Psicologa : AppCompatActivity() {


    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityPsicologaBinding
    val db = Firebase.firestore

    val ref = FirebaseAuth.getInstance();
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPsicologaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.button4.setOnClickListener { view ->
            val email = binding.PsicologaEmail.text.toString()
            val senha = binding.PsicologaSenha.text.toString()
            val dtnasc = binding.DatanascimentoDoutor.text.toString()
            val crm = binding.CRMCRP.text.toString()
            val nomedoutor = binding.NomeDoutor.text.toString()

            if (email.isBlank() || senha.isBlank() || dtnasc.isBlank() || crm.isBlank() || nomedoutor.isBlank()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_LONG).show()

            } else{
                val user = hashMapOf(
                    "Email" to email,
                    "Nome" to nomedoutor,
                    "CRM" to crm,
                    "Data de Nascimento" to dtnasc,
                    "Doutor" to true
                )
                ref.createUserWithEmailAndPassword(email, senha)
                    .addOnCompleteListener { cadastro ->
                        if (cadastro.isSuccessful) {
                            Toast.makeText(this, "Cadastrado", Toast.LENGTH_LONG).show()

                            db.collection("Doutores")
                                .add(user)
                                .addOnSuccessListener { documento ->
                                    Log.d(ContentValues.TAG, "Doutor cadastrado com ID: ${documento.id}")
                                    db.collection("Doutores")
                                        .document("${documento.id}")
                                        .set(hashMapOf("Meu iD" to "${documento.id}"), SetOptions.merge())

                                    //public val itemList= arrayListOf("${documento.id}")
                                }
                                .addOnFailureListener { e ->
                                    Log.w(ContentValues.TAG, "Erro ao adicionar paciente", e)
                                }
                            var intent = Intent(this, Login::class.java)
                            startActivity(intent)
                            finish()
                        }
                    }.addOnFailureListener {

                    }
            }

        }
    }

}