package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.psiqu.databinding.ActivityChecarConsultaBinding
import com.example.psiqu.databinding.ActivityPerfisListaBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MinhasConsultas : AppCompatActivity() {
    val db = Firebase.firestore
    private lateinit var checarconsultar: ActivityChecarConsultaBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        val hora = intent.getStringExtra("hora")
        val nome = intent.getStringExtra("nome")
        val data = intent.getStringExtra("minhadata")
        val sobre = intent.getStringExtra("sobre")
        val idpaciente = intent.getStringExtra("paciente").toString()
        val iddoutor = intent.getStringExtra("doutor").toString()

        val paciente = db.collection("Pacientes").document(idpaciente)
        val doutor = db.collection("Doutores").document(iddoutor)

        val consulta = intent.getStringExtra("consulta").toString()


        checarconsultar = ActivityChecarConsultaBinding.inflate(layoutInflater)
        checarconsultar.NomePacientee.setText(nome)
        checarconsultar.HoraMarcada.setText(hora)
        checarconsultar.DataMarcada.setText(data)
        checarconsultar.Aboutpaciente.setText(sobre)





        checarconsultar.DeletarConsulta.setOnClickListener{
            db.collection("Consultas").document(consulta)
                .delete()
                .addOnSuccessListener { Log.d(ContentValues.TAG, "DocumentSnapshot successfully deleted!")
                }
                .addOnFailureListener { e -> Log.w(ContentValues.TAG, "Error deleting document", e) }


            paciente.get().addOnSuccessListener { doc ->
                 var intent = Intent(this,Home::class.java)
                  intent.putExtra("email", "${doc.get("Email")}")
                  intent.putExtra("nomepaciente", "${doc.get("Nome")}")
                  startActivity(intent)}

            doutor.get().addOnSuccessListener { doc ->
    var intent = Intent(this,Home::class.java)
    intent.putExtra("email", "${doc.get("Email")}")
    intent.putExtra("Iddoutor", "${doc.get("Meu iD")}")
    intent.putExtra("NomeDoutor", "${doc.get("Nome")}")
    startActivity(intent)

}



        }



        setContentView(checarconsultar.root)
    }
}