package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.example.psiqu.databinding.ActivityPerfilupdatepacienteBinding
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import java.io.ByteArrayOutputStream
import java.io.InputStream

class perfilupdatepaciente : AppCompatActivity() {
    val db = Firebase.firestore
    private lateinit var editperfilpac : ActivityPerfilupdatepacienteBinding
    lateinit var  inputstreamfodas: InputStream

    var resultLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { result : Uri ->

        inputstreamfodas = contentResolver.openInputStream(result)!!
        //essaimage.putStream(inputstreamfodas)

        val bitmap = BitmapFactory.decodeStream(inputstreamfodas)
        inputstreamfodas.close()


        editperfilpac.Fotoperfil.setImageBitmap(bitmap)

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        editperfilpac = ActivityPerfilupdatepacienteBinding.inflate(layoutInflater)
        val idpaciente = intent.getStringExtra("id").toString()
        db.collection("Pacientes").document(idpaciente).get().addOnSuccessListener { docs ->
           editperfilpac.NomePaciente.setText("${docs.get("Nome")}")
           editperfilpac.DataPaciente.setText("${docs.get("Data de Nascimento")}")
           editperfilpac.EmailPaciente.setText("${docs.get("Email")}")
            editperfilpac.Local.setText("${docs.get("Local")}")

    }



        setContentView(editperfilpac.root)
        editperfilpac.EscolherImagemPerfil.setOnClickListener{
            resultLauncher.launch("image/*")

        }

        editperfilpac.CONFIRMAR.setOnClickListener{
            val nome = editperfilpac.NomePaciente.text.toString()
            val meuemail = editperfilpac.EmailPaciente.text.toString()
            val nascimento = editperfilpac.DataPaciente.text.toString()
            val local = editperfilpac.Local.text.toString()

            val user = hashMapOf(
                "Email" to meuemail,
                "Nome" to nome,
                "Local" to local,
                "Data de Nascimento" to nascimento
            )

            db.collection("Pacientes").document(idpaciente).set(user, SetOptions.merge()).addOnSuccessListener{ doc ->
                Log.d(ContentValues.TAG, "Doc atualizado")

            }

            var storage = Firebase.storage

            var storageRef = storage.reference
            var imagesRef: StorageReference? = storageRef.child(idpaciente+"/"+"imageperfil.jpg")
            editperfilpac.Fotoperfil.isDrawingCacheEnabled = true
            editperfilpac.Fotoperfil.buildDrawingCache()
            val bitmap = ( editperfilpac.Fotoperfil.drawable as BitmapDrawable).bitmap
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val data = baos.toByteArray()

            var uploadTask = imagesRef!!.putBytes(data)

            var intent = Intent(this,Home::class.java)
            intent.putExtra("email", meuemail)
            intent.putExtra("Iddoutor", idpaciente)
            intent.putExtra("NomeDoutor", nome)
            startActivity(intent)
        }
    }

}