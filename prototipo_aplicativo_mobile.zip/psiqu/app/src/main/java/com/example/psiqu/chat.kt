package com.example.psiqu

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.firebase.ktx.Firebase
import com.example.psiqu.databinding.ActivityChatBinding
import android.util.Log
import android.widget.LinearLayout
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ktx.firestore



class chat : AppCompatActivity() {
    val db = Firebase.firestore
    private lateinit var telachat: ActivityChatBinding


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        telachat = ActivityChatBinding.inflate(layoutInflater)
        setContentView(telachat.root)
        val send = telachat.MandarMensagem


        val nomeuser = intent.getStringExtra("user").toString()
        val iduser = intent.getStringExtra("iddoutor").toString()
        val email = intent.getStringExtra("email")

        val teste = nomeuser+iduser+email

        val essedoc = nomeuser+iduser

        val conversaid = hashMapOf("ConversaID" to nomeuser+iduser)

        val identificador_paciente_conversa = hashMapOf(essedoc to true)


        val enough = db.collection("Conversas").document(essedoc)
        enough.get()
            .addOnSuccessListener { document ->
                  if (document.exists()){
                      Log.d(ContentValues.TAG, "Conversa encontrada: ${document.data}")
                  }else{
                      Log.d(ContentValues.TAG, "Nao ha conversas registradas!")
                      Log.d(ContentValues.TAG, "Criando conversa...")
                      enough.set(conversaid)
                  }


                db.collection("Conversas").
                document(essedoc).
                collection(teste)
                    .orderBy("Tempo", com.google.firebase.firestore.Query.Direction.ASCENDING)
                    .get()
                    .addOnSuccessListener{ documento->
                        for(docs in documento){
                            val mensagemdb = getLayoutInflater().inflate(R.layout.mensagens_mostrar, null);
                            val mensagens = mensagemdb.findViewById<TextView>(R.id.estamensagem)
                            val mostrarmensagens = findViewById<LinearLayout>(R.id.mostrarestamensagem)

                            mensagens.setText ("${docs.get("Mensagem")}")
                            mostrarmensagens.addView(mensagemdb)


                        }

                    }

            }.addOnFailureListener{ e ->
                Log.w(ContentValues.TAG, "Erro ao adicionar conversa", e)

            }


        send.setOnClickListener{
            val tempo = System.currentTimeMillis();
            val tempo_men = tempo.toString();
            val editmen = telachat.MensagemEdit.text.toString()
            val men = hashMapOf("Mensagem" to editmen, "Tempo" to tempo_men)

            //enough.set(myemail, SetOptions.merge())

            db.collection("Conversas").
            document(essedoc).
            collection(teste)
                .add(men)
                .addOnSuccessListener { documento ->
                Log.d(ContentValues.TAG, "Mensagem  cadastrada...")
                    if (email != null) {
                        Log.d(ContentValues.TAG, email)
                    }

                    val mensagemdb = getLayoutInflater().inflate(R.layout.mensagens_mostrar, null);
                val mensagens = mensagemdb.findViewById<TextView>(R.id.estamensagem)
                val mostrarmensagens = findViewById<LinearLayout>(R.id.mostrarestamensagem)

                    db.collection("Pacientes").whereEqualTo("Email", email).get().addOnSuccessListener { mydoc ->
                        for(docs in mydoc){
                            Log.d(ContentValues.TAG,"bungas: ${docs.data}")
                            if(docs.exists()) {
                                Log.d(ContentValues.TAG,"bungas: ${docs.data}")
                                db.collection("Pacientes").document("${docs.id}").set(identificador_paciente_conversa, SetOptions.merge())
                            }
                        }
                    }

                    mensagens.setText(editmen)
                    mostrarmensagens.addView(mensagemdb)
        }


/*
    enough.set(men,SetOptions.merge()).addOnSuccessListener {
        Log.d(ContentValues.TAG, "Mensagem cadastrada")
    }*/
}

    }
}


