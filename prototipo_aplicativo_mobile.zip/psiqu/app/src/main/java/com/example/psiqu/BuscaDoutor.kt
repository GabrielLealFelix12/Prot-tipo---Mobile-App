package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.psiqu.databinding.ActivityPerfisListaBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.example.psiqu.Paciente


class BuscaDoutor : AppCompatActivity() {
    val db = Firebase.firestore
    //val esseid =
    private lateinit var listauser: ActivityPerfisListaBinding
    //var bruh = getIntent()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //mudar.setText("Obungas")
        val email = intent.getStringExtra("email")
        listauser = ActivityPerfisListaBinding.inflate(layoutInflater)
        setContentView(listauser.root)
        //val conts = db.collection("Usuarios").whereNotEqualTo("Meu iD", null).get()


        //espacolista.addView(userparalista)
        db.collection("Doutores")
            .whereNotEqualTo("Meu iD", null)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {

                    val userparalista = getLayoutInflater().inflate(R.layout.perfis_imagens, null);
                    val mudar = userparalista.findViewById<TextView>(R.id.name)
                    val nomedoutor = userparalista.findViewById<Button>(R.id.IdDoutor)
                    val espacolista = findViewById<LinearLayout>(R.id.container)

                    Log.d(ContentValues.TAG, "${document.get("Nome")}")


                    mudar.setText ("${document.get("Nome")}")
                    nomedoutor.setText("${document.get("Meu iD")}")

                    val esteemail = "${document.get("Email")}"
                    val estenome = "${document.get("Nome")}"
                    val formacao = "${document.get("Formação")}"
                    val local = "${document.get("Localidade")}"
                    val dias = "${document.get("Dias")}"


                    espacolista.addView(userparalista)

                    userparalista.setOnClickListener{ atividade->
                        val nome_do_doutor = mudar.text;
                        val iddoutor = nomedoutor.text
                        //val busca = hashMapOf("Nome" to nome_do_doutor, "Meu id" to iddoutor)

                        val intent = Intent(this, PerfilPsicolog::class.java)
                        intent.putExtra("user", nome_do_doutor)
                        intent.putExtra("iddoutor", iddoutor)
                        intent.putExtra("email", esteemail)
                        intent.putExtra("localidade", local)
                        intent.putExtra("formação", formacao)
                        intent.putExtra("dias", dias)
                        startActivity(intent)
                        }

                }
            }
            .addOnFailureListener { exception ->
                Log.w(ContentValues.TAG, "Erro ao pedir documentos: ", exception)
            }


    }


}
