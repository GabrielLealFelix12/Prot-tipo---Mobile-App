package com.example.psiqu

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ContentValues
import android.os.Bundle
import android.util.Log
//import android.os.PersistableBundle
//import android.view.LayoutInflater
import android.view.View
import android.widget.DatePicker
import android.widget.TimePicker
//import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
//import androidx.appcompat.widget.AlertDialogLayout
import com.example.psiqu.databinding.ActivityMarcarDataBinding
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.lang.StringBuilder
import java.text.SimpleDateFormat
//import java.time.Clock
import java.util.*
//import java.util.stream.DoubleStream.builder

class CalendarioConsulta :AppCompatActivity() {
    lateinit var marcardata: ActivityMarcarDataBinding
    var cal = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        marcardata = ActivityMarcarDataBinding.inflate(layoutInflater)
        marcardata.NomePacientee.setText(intent.getStringExtra("nomepaciente"))
        setContentView(marcardata.root)

        val dateSetListener = object : DatePickerDialog.OnDateSetListener {
            override fun onDateSet(
                view: DatePicker, year: Int, monthOfYear: Int,
                dayOfMonth: Int
            ) {
                cal.set(Calendar.YEAR, year)
                cal.set(Calendar.MONTH, monthOfYear)
                cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                updateDateInView()
            }
        }

        val horalistener = object : TimePickerDialog.OnTimeSetListener {
            override fun onTimeSet(
                view: TimePicker,
                hourOfDay: Int,
                minute: Int
            ) {
                cal.set(Calendar.HOUR_OF_DAY, hourOfDay)
                cal.set(Calendar.MINUTE, minute)
                val horafinal = StringBuilder()

                horafinal.append(hourOfDay)
                    .append(":")
                    .append(minute)
                marcardata.HoraMarcada.setText(horafinal.toString())
            }
        }

        marcardata.SetDataConsulta.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View) {
                DatePickerDialog(
                    this@CalendarioConsulta,
                    AlertDialog.THEME_DEVICE_DEFAULT_DARK,
                    dateSetListener,
                    // set DatePickerDialog to point to today's date when it loads up
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH)
                ).show()
            }

        })


        marcardata.marcarHora.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View) {
                TimePickerDialog(
                    this@CalendarioConsulta,
                    AlertDialog.THEME_DEVICE_DEFAULT_DARK,
                    horalistener,
                    // set DatePickerDialog to point to today's date when it loads up
                    cal.get(Calendar.HOUR_OF_DAY),
                    cal.get(Calendar.MINUTE),
                    true
                ).show()
            }

        })

        marcardata.Definirdata.setOnClickListener{
            val horamarcada = marcardata.HoraMarcada.text
            val datamarcada = marcardata.DataMarcada.text
            val aboutpaciente = marcardata.Aboutpaciente.text.toString()

            val pacienteid = intent.getStringExtra("id")
            val doutorid = intent.getStringExtra("iddoutor")
            val db = Firebase.firestore

            val consulta = hashMapOf(
            "Hora marcada" to horamarcada,
            "Data marcada" to datamarcada,
            "Doutor" to doutorid,
                "Paciente" to pacienteid,
                "Sobre" to aboutpaciente,
                "NomePaciente" to intent.getStringExtra("nomepaciente"),
                "NomeDoutor" to intent.getStringExtra("nomedoutor")
        )
            db.collection("Consultas").add(consulta).addOnSuccessListener { doc ->
            Log.d(ContentValues.TAG, "Consulta cadastrada com ID: ${doc.id}")
                db.collection("Consultas")
                    .document("${doc.id}")
                    .set(hashMapOf("Consulta Id" to "${doc.id}"), SetOptions.merge())
                    .addOnFailureListener { e ->
                    Log.w(ContentValues.TAG, "Erro ao adicionar consulta", e)
                }
        }
        finish()
        }

    }




    private fun updateDateInView() {
        val myFormat = "dd/MM/yyyy" // mention the format you need
        val sdf = SimpleDateFormat(myFormat)
        marcardata.DataMarcada.setText(sdf.format(cal.getTime()))
    }
}