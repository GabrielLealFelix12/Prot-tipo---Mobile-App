package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import android.content.UriMatcher
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.ContentView
import com.example.psiqu.databinding.ActivityPerfilPsicologBinding
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import com.squareup.picasso.Picasso
import java.io.File
import java.net.URL

class PerfilPaciente : AppCompatActivity() {
    //private lateinit var perfil_dr: ActivityPerfilPsicologBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //perfil_dr= ActivityPerfilPsicologBinding.inflate(layoutInflater)
        val minhastorage = Firebase.storage
        var storageref = minhastorage.reference





        //val userdoutor = intent.getStringExtra("user")
        val nomepaciente = intent.getStringExtra("nome")
        val nomedoutor = intent.getStringExtra("nomedoutor")
        val emailpaciente = intent.getStringExtra("email").toString()
        val problemapaciente = intent.getStringExtra("problema")
        val idpaciente = intent.getStringExtra("iddoutor")
        val iddoutor = intent.getStringExtra("doutorid")
        val minhalocal = intent.getStringExtra("Local")



        val perfildoutor = getLayoutInflater().inflate(R.layout.activity_perfil_paciente, null)
        val meunome = perfildoutor.findViewById<TextView>(R.id.Nome_paciente)
        val meuemail = perfildoutor.findViewById<TextView>(R.id.EmailPaciente)
        val minhadoenca = perfildoutor.findViewById<TextView>(R.id.ProblemaPaciente)
        val meulocal = perfildoutor.findViewById<TextView>(R.id.Localizacao)

        //val minhalocal = perfildoutor.findViewById<TextView>(R.id.Localizacao).text

        //val editperfil = perfildoutor.findViewById<ImageView>(R.id.EditPerfil)
        val minhahome = perfildoutor.findViewById<ImageView>(R.id.minhahome)
        val perfilfoto = perfildoutor.findViewById<ImageView>(R.id.Img_doutor)
        val agendinha = perfildoutor.findViewById<ImageButton>(R.id.agendinha)


        minhahome.setOnClickListener{
            finish()
        }
        agendinha.setOnClickListener{
            val paginacalendar = Intent(this, CalendarioConsulta::class.java)
            paginacalendar.putExtra("id", idpaciente)
            paginacalendar.putExtra("iddoutor", iddoutor)
            paginacalendar.putExtra("nomepaciente", nomepaciente)
            paginacalendar.putExtra("nomedoutor", nomedoutor)
            startActivity(paginacalendar)

        }

        meunome.setText(nomepaciente)
        meuemail.setText(emailpaciente)
        meulocal.setText(minhalocal)
        minhadoenca.setText(problemapaciente)
//Log.d(ContentValues.TAG, meupath)
        //Picasso.get().load(meupath).into(perfilfoto);

        storageref.child(idpaciente+"/"+"imageperfil.jpg").downloadUrl.addOnSuccessListener { result ->
            Log.d(ContentValues.TAG, result.toString())
            Picasso.get().load(result).into(perfilfoto)
        }


        setContentView(perfildoutor)


    }
}