package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import com.example.psiqu.databinding.ActivityPerfisListaBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*
import kotlin.math.log


class ChecarConsultas : AppCompatActivity() {
    val db = Firebase.firestore
    private lateinit var listauser: ActivityPerfisListaBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val idpaciente = intent.getStringExtra("idpaciente")
        val iddoutor = intent.getStringExtra("iddoutor")


        listauser = ActivityPerfisListaBinding.inflate(layoutInflater)
        setContentView(listauser.root)

        val consultadoc = db.collection("Consultas").whereEqualTo("Doutor", iddoutor)
        val consultapac = db.collection("Consultas").whereEqualTo("Paciente", idpaciente)


        consultapac.get().addOnSuccessListener { documents ->
            for(docs in documents){
                val pageconsultas = getLayoutInflater().inflate(R.layout.calendario_consultas, null);
                val hora = pageconsultas.findViewById<TextView>(R.id.hora)
                val minhadata = pageconsultas.findViewById<TextView>(R.id.data)
                val espacolista = findViewById<LinearLayout>(R.id.container)
                val botaochecar = pageconsultas.findViewById<ImageButton>(R.id.checar)
                val nome = pageconsultas.findViewById<TextView>(R.id.Nomedoutor)
                val sobre = pageconsultas.findViewById<TextView>(R.id.sobre)


                hora.setText("${docs.get("Hora marcada")}")
                minhadata.setText("${docs.get("Data marcada")}")
                nome.setText("${docs.get("NomeDoutor")}")
                sobre.setText("${docs.get("Sobre")}")


                botaochecar.setOnClickListener{
                    val intent = Intent(this, MinhasConsultas::class.java)
                    intent.putExtra("hora", hora.text.toString())
                    intent.putExtra("minhadata", minhadata.text.toString())
                    intent.putExtra("nome", nome.text.toString())
                    intent.putExtra("sobre", sobre.text.toString())
                    //intent.putExtra("doutor","${docs.get("Doutor")}" )
                    intent.putExtra("paciente","${docs.get("Paciente")}" )
                    intent.putExtra("consulta", "${docs.get("Consulta Id")}" )


                    startActivity(intent)

                }

                espacolista.addView(pageconsultas)

            }
        }
        consultadoc.get().addOnSuccessListener { documents ->
            for(docs in documents){
                val pageconsultas = getLayoutInflater().inflate(R.layout.calendario_consultas, null);
                val hora = pageconsultas.findViewById<TextView>(R.id.hora)
                val minhadata = pageconsultas.findViewById<TextView>(R.id.data)
                val nome = pageconsultas.findViewById<TextView>(R.id.Nomedoutor)
                val sobre = pageconsultas.findViewById<TextView>(R.id.sobre)
                val botaochecar = pageconsultas.findViewById<ImageButton>(R.id.checar)
                val espacolista = findViewById<LinearLayout>(R.id.container)


                hora.setText("${docs.get("Hora marcada")}")
                minhadata.setText("${docs.get("Data marcada")}")
                nome.setText("${docs.get("NomePaciente")}")
                sobre.setText("${docs.get("Sobre")}")

                botaochecar.setOnClickListener{
                    val intent = Intent(this, MinhasConsultas::class.java)
                    intent.putExtra("hora", hora.text.toString())
                    intent.putExtra("minhadata", minhadata.text.toString())
                    intent.putExtra("nome", nome.text.toString())
                    intent.putExtra("sobre", sobre.text.toString())
                    intent.putExtra("doutor","${docs.get("Doutor")}" )
                    //intent.putExtra("paciente","${docs.get("Paciente")}" )
                    intent.putExtra("consulta", "${docs.get("Consulta Id")}" )

                    startActivity(intent)

                }

                espacolista.addView(pageconsultas)

            }
        }
    }
}