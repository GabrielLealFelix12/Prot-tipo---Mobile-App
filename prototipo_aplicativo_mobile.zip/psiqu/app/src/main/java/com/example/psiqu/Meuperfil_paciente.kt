package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.ContentView
import com.example.psiqu.databinding.ActivityPerfilPsicologBinding
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import com.squareup.picasso.Picasso

class Meuperfil_paciente : AppCompatActivity() {
    private lateinit var perfil_dr: ActivityPerfilPsicologBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //perfil_dr= ActivityPerfilPsicologBinding.inflate(layoutInflater)

        val minhastorage = Firebase.storage
        var storageref = minhastorage.reference



        //val userdoutor = intent.getStringExtra("user")
        val nomepaciente = intent.getStringExtra("nome")
        val emailpaciente = intent.getStringExtra("email").toString()
        val minhalocal = intent.getStringExtra("Local")
        val problemapaciente = intent.getStringExtra("problema")
        val idpaciente = intent.getStringExtra("id")

        val perfildoutor = getLayoutInflater().inflate(R.layout.activity_meuperfil_paciente, null)
        val meunome = perfildoutor.findViewById<TextView>(R.id.Nomepaciente)
        //val meuemail = perfildoutor.findViewById<TextView>(R.id.EmailPaciente)
        val minhadoenca = perfildoutor.findViewById<TextView>(R.id.ProblemaPaciente)
        val meulocal = perfildoutor.findViewById<TextView>(R.id.Localizacao)
        //val minhalocal = perfildoutor.findViewById<TextView>(R.id.Localizacao).text
        val perfilfoto = perfildoutor.findViewById<ImageView>(R.id.Img_doutor)

        //val meuuniversidade = perfildoutor.findViewById<TextView>(R.id.UniversidadeDoutor).text
        //val localatendimento = perfildoutor.findViewById<TextView>(R.id.LocalAtendimento).text

        val editperfil = perfildoutor.findViewById<ImageView>(R.id.EditPerfil)
        val minhahome = perfildoutor.findViewById<ImageView>(R.id.minhahome)

        editperfil.setOnClickListener{
            val intent = Intent(this, perfilupdatepaciente::class.java)
            intent.putExtra("nome", nomepaciente)
            intent.putExtra("email", emailpaciente)
            intent.putExtra("id", idpaciente)

            //intent.putExtra("Formação", meuuniversidade )
            //intent.putExtra("LocalAtendimento", localatendimento)

            startActivity(intent)
        }

        minhahome.setOnClickListener{
            finish()
        }
        meunome.setText(nomepaciente)
        //meuemail.setText(emailpaciente)
        minhadoenca.setText(problemapaciente)
        meulocal.setText(minhalocal)

        storageref.child(idpaciente+"/"+"imageperfil.jpg").downloadUrl.addOnSuccessListener { result ->
            Log.d(ContentValues.TAG, result.toString())
            Picasso.get().load(result).into(perfilfoto)
        }

        setContentView(perfildoutor)


    }
}