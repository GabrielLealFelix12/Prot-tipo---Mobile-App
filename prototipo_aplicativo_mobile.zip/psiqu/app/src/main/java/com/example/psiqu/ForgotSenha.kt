package com.example.psiqu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import com.example.psiqu.databinding.ActivityForgotSenhaBinding

class ForgotSenha : AppCompatActivity() {
    private  lateinit var binding: ActivityForgotSenhaBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_senha)
        binding = ActivityForgotSenhaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.imageButton5.setOnClickListener {
            var Intent = Intent(this,Login::class.java)
            startActivity(Intent)
            finish()
        }

    }
}