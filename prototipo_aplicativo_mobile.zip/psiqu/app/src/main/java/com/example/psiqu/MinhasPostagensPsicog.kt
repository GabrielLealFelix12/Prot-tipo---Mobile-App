package com.example.psiqu

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.psiqu.databinding.ActivityPublicacoesBinding
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import java.io.ByteArrayOutputStream
import java.io.InputStream

class MinhasPostagensPsicog : AppCompatActivity() {
    val db = Firebase.firestore
    private lateinit var meusposts: ActivityPublicacoesBinding
    lateinit var  inputstreamfodas: InputStream


    var resultLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { result : Uri ->
        inputstreamfodas = contentResolver.openInputStream(result)!!
        val bitmap = BitmapFactory.decodeStream(inputstreamfodas)
        inputstreamfodas.close()
        meusposts.imagemPublic.setImageBitmap(bitmap)

    }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        val id = intent.getStringExtra("id")

        meusposts = ActivityPublicacoesBinding.inflate(layoutInflater)
        setContentView(meusposts.root)


        meusposts.imagemPublic.setOnClickListener{
            resultLauncher.launch("image/*")
        }
        meusposts.Postar.setOnClickListener{

            val tempo = System.currentTimeMillis();
            val tempo_men = tempo.toString();
            val publictext = meusposts.TextoPublic.text.toString()


            val meupost = hashMapOf(
                "tempo" to tempo_men,
                "doutor" to id,
                "TextoPubli" to publictext
                )
            db.collection("Posts").add(meupost).addOnSuccessListener {doc ->
                db.collection("Posts")
                    .document("${doc.id}")
                    .set(hashMapOf("Meu iD" to "${doc.id}"), SetOptions.merge())

                val estepost = "${doc.id}".toString()
                var storage = Firebase.storage



            var storageRef = storage.reference
            var imagesRef: StorageReference? = storageRef.child(id+"/"+estepost)
            meusposts.imagemPublic.isDrawingCacheEnabled = true
            meusposts.imagemPublic.buildDrawingCache()
            val bitmap = ( meusposts.imagemPublic.drawable as BitmapDrawable).bitmap
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val data = baos.toByteArray()

            var uploadTask = imagesRef!!.putBytes(data)




            uploadTask.addOnFailureListener {
                Log.e(ContentValues.TAG,"Error")
            }
                .addOnSuccessListener { taskSnapshot ->
                    Log.d(ContentValues.TAG, "done: " + taskSnapshot.metadata)
                }
        }
finish()

    }
}
}