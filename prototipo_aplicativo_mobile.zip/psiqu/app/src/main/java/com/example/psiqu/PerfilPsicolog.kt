package com.example.psiqu

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.ContentView
import com.example.psiqu.databinding.ActivityPerfilPsicologBinding
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import com.squareup.picasso.Picasso

class PerfilPsicolog : AppCompatActivity() {
    //private lateinit var perfil_dr: ActivityPerfilPsicologBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val minhastorage = Firebase.storage
        var storageref = minhastorage.reference
        //perfil_dr= ActivityPerfilPsicologBinding.inflate(layoutInflater)





        //val userdoutor = intent.getStringExtra("user")
        val nomedoutor = intent.getStringExtra("user")
        val emaildoutor = intent.getStringExtra("email").toString()
        val localizacao = intent.getStringExtra("localidade")
        val formacao = intent.getStringExtra("formação")
        val id = intent.getStringExtra("iddoutor")
        val dias = intent.getStringExtra("dias")



        val perfildoutor = getLayoutInflater().inflate(R.layout.activity_perfil_psicolog, null)
        val meunome = perfildoutor.findViewById<TextView>(R.id.Nome_doutor)
        val meuemail = perfildoutor.findViewById<TextView>(R.id.EmailDoutor)
        val meuuniversidade = perfildoutor.findViewById<TextView>(R.id.UniversidadeDoutor)
        val localatendimento = perfildoutor.findViewById<TextView>(R.id.LocalAtendimento)
        val meusdias = perfildoutor.findViewById<TextView>(R.id.DiasAtendimento)

        //val editperfil = perfildoutor.findViewById<ImageView>(R.id.EditPerfil)
        val minhahome = perfildoutor.findViewById<ImageView>(R.id.minhahome)

        val perfilfoto = perfildoutor.findViewById<ImageView>(R.id.Img_doutor)


        minhahome.setOnClickListener{
            finish()
        }

        meunome.setText(nomedoutor)
        meuemail.setText(emaildoutor)
        meuuniversidade.setText(formacao)
        localatendimento.setText(localizacao)
        meusdias.setText(dias)



        storageref.child(id+"/"+"imageperfil.jpg").downloadUrl.addOnSuccessListener { result ->
            Log.d(ContentValues.TAG, result.toString())
            Picasso.get().load(result).into(perfilfoto)
        }
        setContentView(perfildoutor)


    }
}